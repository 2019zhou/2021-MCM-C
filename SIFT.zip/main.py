import csv
import os
from sklearn.cluster import KMeans
import cv2
import numpy as np
import pickle
import os

def sift_detect(file_list):
    content = []
    input_x = []
    labels=[]
    features = []
    count = 0
    globalids = []

    dir = './dataset/2021MCM_ProblemC_Files/'
    files = os.listdir(dir)


    with open(file_list, 'r') as f:
        next(f)	
        for line in f:
            line = line.strip().split(',')
            tmp = line[1]
            tmp = tmp[:-4]
            for file2 in files:
              if file2.find(tmp) == -1:
                continue
              else:
                filepath = dir + file2
                print(filepath)
                sift = cv2.xfeatures2d.SIFT_create(200)
                img = cv2.imdecode(np.fromfile(filepath, dtype=np.uint8),-1)
                if img is not None:
                    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                    kpG, desG = sift.detectAndCompute(gray, None)
                    if desG is None:
                        continue
                    l = line[3]
                    if l == "Negative ID":
                        label = 0
                    elif l == "Positive ID":
                        label = 1
                        input_x.extend(desG)
                    labels.append(label)
                    features.append(desG)
                    globalids.append(line[2])

    return features, labels, input_x, globalid

des_list = []
label_train = []
input_x1 = []
features_train, labels_train, input_x, globalid = sift_detect('./index.csv')

output = open('input_x.pkl', 'wb')
pickle.dump(input_x, output)
output.close()

output = open('features_train.pkl', 'wb')
pickle.dump(features_train, output)
output.close()

output = open('labels_train.pkl', 'wb')
pickle.dump(labels_train, output)
output.close()

output = open('globalid.pkl', 'wb')
pickle.dump(globalid, output)
output.close()