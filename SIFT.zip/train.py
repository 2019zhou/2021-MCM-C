import pickle
from random import choice
from sklearn.cluster import KMeans
from sklearn.svm import SVC
import numpy as np
from sklearn.model_selection import cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier #随机森林

sc = StandardScaler()

def des2feature(centers, des, num_words):
    '''
    des:单幅图像的SIFT特征描述
    num_words:视觉单词数/聚类中心数
    centers:聚类中心坐标  
    计算特征矩阵中特征点离聚类中心最近的加1 
    return: feature vector 1*num_words
    '''
    img_feature_vec = np.zeros([num_words])
    for fi in des:
        diffMat = np.tile(fi, (15, 1)) - centers
        sqSum = (diffMat**2).sum(axis=1)
        dist = sqSum**0.5
        sortedIndices = dist.argsort()
        idx = sortedIndices[0] # index of the nearest center
        #排序得到距离最近的聚类中心坐标的索引
        img_feature_vec[idx] += 1
    return img_feature_vec

def get_all_features(dess, num_words):
    # 获取所有图片的特征向量
    allvec = np.zeros((len(dess), num_words),'float32')
    for i in range(len(dess)):
        if dess[i].any() != None:
            allvec[i] = des2feature(centers=centers, des=dess[i], num_words=num_words)
    return allvec

df = open('input_x.pkl','rb')
input_x = pickle.load(df)
df.close()

df = open('features_train.pkl', 'rb')
dess = pickle.load(df)
df.close()

df = open('labels_train.pkl', 'rb')
train_labels = pickle.load(df)
df.close()

# df = open('centers.pkl', 'rb')
# centers = pickle.load(df)
# df.close()

kmeans = KMeans(n_clusters=15, random_state=None).fit(input_x)
centers = kmeans.cluster_centers_

output = open('centers.pkl', 'wb')
pickle.dump(centers, output)
output.close()

allvec = get_all_features(dess, 15)

X_train = sc.fit_transform(allvec)

positive_samples = []
positive = 0
negative = 0
data = []
labels = []
for f, label in zip(X_train, train_labels):
    if label == 1:
        positive_samples.append(f)
        data.append(f)
        labels.append(0)
        positive += 1
    if label == 0:
        data.append(f)
        labels.append(0)
        negative += 1
    
while positive <= negative / 100:
    data.append(choice(positive_samples))
    labels.append(1)
    positive += 1

accuracy_scores = cross_val_score(SVC(C=15), data, labels, cv=10, scoring='accuracy')
print(np.average(accuracy_scores))

precision_scores = cross_val_score(SVC(C=15), data, labels, cv=10, scoring='precision')
print(np.average(precision_scores))

recall_scores = cross_val_score(SVC(C=15), data, labels, cv=10, scoring='recall')
print(np.average(recall_scores))

F1_scores = cross_val_score(SVC(C=15), data, labels, cv=10, scoring='f1')
print(np.average(F1_scores))

# kmeans = KMeans(n_clusters = 50, n_jobs =4, random_state = None).fit(features)
# #开四个线程加快计算
# centers = kmeans.cluster_centers_

# def img_to_vect(img_descs, cluster_model):
#     """
#     Given an image path and a trained clustering model (eg KMeans),
#     generates a feature vector representing that image.
#     Useful for processing new images for a classifier prediction.
#     """

#     clustered_desc = [cluster_model.predict(raw_words) for raw_words in img_descs]
#     img_bow_hist = np.array(np.bincount(clustered_desc, minlength=cluster_model.n_clusters))
#     return img_bow_hist

# def des2feature(des,num_words,centures):
#     '''
#     des:单幅图像的SIFT特征描述
#     num_words:视觉单词数/聚类中心数
#     centures:聚类中心坐标
#     计算特征矩阵中特征点离聚类中心最近的加1
#     return: feature vector 1*num_words
#     '''
#     img_feature_vec=np.zeros([num_words])
#     for fi in des:
#         diffMat = np.tile(fi, (50, 1)) - centers
#         sqSum = (diffMat**2).sum(axis=1)
#         dist = sqSum**0.5
#         sortedIndices = dist.argsort()
#         idx = sortedIndices[0] # index of the nearest center
#     #排序得到距离最近的聚类中心坐标的索引
#         img_feature_vec[idx] += 1
#     return img_feature_vec

# def get_all_features(des_list,num_words):
#     # 获取所有图片的特征向量
#     allvec = np.zeros((len(des_list),num_words),'float32')
#     for i in range(len(des_list)):
#         if des_list[i].any()!=None:
#             allvec[i] = des2feature(centures=centers,des=des_list[i],num_words=num_words)
#     return allvec

# df = open('des_list.pkl','rb')#注意此处是rb
# #此处使用的是load(目标文件)
# des_list = pickle.load(df)
# df.close()
# a = get_all_features(des_list,50)
# print(len(a))
# output = open('特征向量.pkl', 'wb')
# pickle.dump(a, output)
# output.close()

# import numpy as np
# import matplotlib.pyplot as plt
# import pandas as pd
# import pickle
# from sklearn.preprocessing import StandardScaler
# df = open('label_train.pkl','rb')
# # 此处使用的是load(目标文件)
# label_train = pickle.load(df)
# df.close()
# df = open('label_test.pkl','rb')
# # 此处使用的是load(目标文件)
# label_test =pickle.load(df)
# df.close()
# sc = StandardScaler()
# X_train = sc.fit_transform(a)
# X_test = sc.fit_transform(b)

# from sklearn.svm import SVC
# classifier = SVC(C=15)
# #适当调整参数，不是一个固定值
# classifier.fit(X_train,label_train)

# y_pred = classifier.predict(X_test)

# print(classifier.score(X_train,label_train))
# from sklearn.metrics import classification_report
# print(classification_report(label_test,y_pred))