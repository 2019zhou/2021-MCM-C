import pandas as pd

df_excel = pd.read_excel("./dataset/2021MCM_ProblemC_Images_by_GlobalID.xlsx")
df_csv = pd.read_csv("./dataset/cleaned_data_VM.csv", encoding="utf-8")

col_n = ["FileName", "GlobalID"]
df_excel = pd.DataFrame(df_excel, columns = col_n)
col_n = ["Lab Status", "GlobalID"]
df_csv = pd.DataFrame(df_csv, columns = col_n)
df_csv_ = df_csv[df_csv["Lab Status"].isin(["Positive ID", "Negative ID", "Unprocessed"])]

df = pd.merge(df_excel, df_csv_, how='inner', on="GlobalID", 
            left_index=False, right_index=False, sort=True,
            suffixes=('_x', '_y'), copy=True, indicator=False)

df.to_csv("./index.csv")